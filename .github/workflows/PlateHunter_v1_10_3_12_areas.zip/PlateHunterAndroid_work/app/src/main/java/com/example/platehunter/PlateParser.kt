package com.example.platehunter

object PlateParser {
    private val digits = mapOf(
        "صفر" to "0", "واحد" to "1", "واحدة" to "1", "اثنين" to "2", "اتنين" to "2",
        "اثنان" to "2", "تنين" to "2", "ثلاثة" to "3", "ثلاث" to "3",
        "اربعة" to "4", "أربعة" to "4", "اربعه" to "4", "أربعه" to "4",
        "خمسة" to "5", "خمسه" to "5", "ستة" to "6", "سته" to "6",
        "سبعة" to "7", "سبعه" to "7", "ثمانية" to "8", "تمانية" to "8",
        "ثمانيه" to "8", "تسعة" to "9", "تسعه" to "9"
    )
    /** Spelling normalisation so ألف/الف/إلف, زاي/زاى, هاء/هاة all match. */
    private fun nk(w: String) = w.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')
    /** The 28 Arabic letter names (also sent to Deepgram as keyterms). */
    val letterNames = listOf(
        "ألف", "باء", "تاء", "ثاء", "جيم", "حاء", "خاء", "دال", "ذال", "راء", "زاي", "سين", "شين", "صاد",
        "ضاد", "طاء", "ظاء", "عين", "غين", "فاء", "قاف", "كاف", "لام", "ميم", "نون", "هاء", "واو", "ياء"
    )
    private val letterChars = listOf(
        "ا", "ب", "ت", "ث", "ج", "ح", "خ", "د", "ذ", "ر", "ز", "س", "ش", "ص",
        "ض", "ط", "ظ", "ع", "غ", "ف", "ق", "ك", "ل", "م", "ن", "ه", "و", "ي"
    )
    private val letters: Map<String, String> = run {
        val m = HashMap<String, String>()
        letterNames.forEachIndexed { i, n -> m[nk(n)] = letterChars[i] }
        // common spoken variants
        mapOf("زين" to "ز", "الفا" to "ا", "الف" to "ا", "هاي" to "ه", "ياي" to "ي", "كااف" to "ك", "قااف" to "ق")
            .forEach { (k, v) -> m[nk(k)] = v }
        m
    }
    /** Letters taught by the user (spoken word -> Arabic letter). */
    @Volatile var extraLetters: Map<String, String> = emptyMap()
    /** Word corrections applied to every spoken token before parsing. */
    @Volatile var corrections: Map<String, String> = emptyMap()
    fun letterOf(w: String): String? = nk(w).let { k -> letters[k] ?: extraLetters[w] ?: extraLetters[k] }
    fun digitWord(w: String): String? = digits[w]

    fun normDigits(s: String) = s.replace('٠','0').replace('١','1').replace('٢','2')
        .replace('٣','3').replace('٤','4').replace('٥','5').replace('٦','6')
        .replace('٧','7').replace('٨','8').replace('٩','9')

    fun normalize(s: String): String {
        val x = normDigits(s).replace(Regex("[\\s\\-،,:؛.]"), "")
        val l = x.filter { it in 'ء'..'ي' || it == 'أ' || it == 'إ' || it == 'آ' }
        val d = x.filter { it.isDigit() }
        if (l.length != 3 || d.length !in 3..4) return ""
        return l + if (d.length == 3) "0$d" else d
    }

    fun fromSpeech(s: String): List<String> {
        val t = s.replace(Regex("[،,؛;.!؟?]"), " ").trim().split(Regex("\\s+")).filter { it.isNotBlank() }.map { corrections[it] ?: it }
        val out = mutableListOf<String>()
        var i = 0
        while (i < t.size) {
            val l = StringBuilder(); var j = i
            while (j < t.size && l.length < 3 && letterOf(t[j]) != null) { l.append(letterOf(t[j])); j++ }
            if (l.length == 3) {
                val d = StringBuilder()
                while (j < t.size && d.length < 4) {
                    val raw = normDigits(t[j]).filter { it.isDigit() }
                    if (raw.isNotEmpty()) { d.append(raw); j++ }
                    else if (digits[t[j]] != null) { d.append(digits[t[j]]); j++ }
                    else break
                }
                if (d.length in 3..4) {
                    out.add(l.toString() + if (d.length == 3) "0$d" else d.toString().take(4))
                    i = j; continue
                }
            }
            i++
        }
        if (out.isEmpty()) {
            // Fallback: transcript already contains letters (joined or spaced) followed by digits, e.g. "سرط 7520" or "س ر ط 7 5 2 0"
            val flat = normDigits(s).replace(Regex("[،,؛;.!؟?\\-:]"), " ")
            Regex("(?<![\\u0621-\\u064A])((?:[\\u0621-\\u064A]\\s*){3})(?![\\u0621-\\u064A])\\s*((?:[0-9]\\s*){3,4})").findAll(flat).forEach {
                val p = normalize(it.groupValues[1] + it.groupValues[2])
                if (p.isNotBlank()) out.add(p)
            }
        }
        return out.distinct()
    }
}
